"""
Compositeur vidéo PRO avec :
- Sous-titres depuis le texte du script (pas de transcription = 0 faute)
- Banque de vidéos locales pré-sélectionnées (ou Pexels en fallback)
- Style TikTok optimisé
"""

import os
import random
import subprocess
import re
from pathlib import Path
from typing import Optional
import httpx
from rich.console import Console

from src.config import settings
from src.models import AudioFile, Script, SubtitleSegment, Subtitles, Video, VideoStatus

console = Console()


# === BANQUE DE VIDÉOS LOCALES ===
# Place tes vidéos pré-sélectionnées dans assets/backgrounds/
# Nommées par catégorie : road_1.mp4, road_2.mp4, document_1.mp4, etc.

LOCAL_VIDEO_CATEGORIES = {
    "scandale": ["road", "highway", "traffic", "radar"],
    "tuto": ["document", "paper", "phone", "desk"],
    "temoignage": ["happy", "relief", "car", "driver"],
    "mythe": ["thinking", "question", "idea"],
    "chiffre_choc": ["money", "euro", "wallet", "cash"],
}

# Mots-clés Pexels (fallback si pas de vidéos locales)
PEXELS_KEYWORDS = {
    "scandale": ["car driving highway", "speed limit road", "traffic city"],
    "tuto": ["writing document", "paperwork office", "smartphone typing"],
    "temoignage": ["happy person relief", "good news reaction", "stress free"],
    "mythe": ["thinking person", "question mark", "idea concept"],
    "chiffre_choc": ["euro money", "wallet cash", "counting bills"],
}

# Couleurs de fond dégradé par format (fallback ultime)
GRADIENT_COLORS = {
    "scandale": ("#FF4B4B", "#8B0000"),
    "tuto": ("#4ECDC4", "#1A535C"),
    "temoignage": ("#45B7D1", "#1E3A5F"),
    "mythe": ("#9B59B6", "#4A235A"),
    "chiffre_choc": ("#F39C12", "#7D4E00"),
}


class PexelsClient:
    """Client pour télécharger des vidéos de fond depuis Pexels (fallback)."""
    
    BASE_URL = "https://api.pexels.com/videos/search"
    
    def __init__(self):
        self.api_key = os.getenv("PEXELS_API_KEY", "")
    
    def search_videos(self, query: str, orientation: str = "portrait", per_page: int = 5) -> list[dict]:
        """Recherche des vidéos sur Pexels."""
        if not self.api_key:
            return []
        
        try:
            response = httpx.get(
                self.BASE_URL,
                params={
                    "query": query,
                    "orientation": orientation,
                    "per_page": per_page,
                    "size": "medium",
                },
                headers={"Authorization": self.api_key},
                timeout=15,
            )
            response.raise_for_status()
            return response.json().get("videos", [])
        except Exception as e:
            console.print(f"[yellow]Pexels API error: {e}[/yellow]")
            return []
    
    def download_video(self, video_data: dict, output_path: Path) -> Optional[Path]:
        """Télécharge une vidéo Pexels (720p max pour performance)."""
        try:
            video_files = video_data.get("video_files", [])
            
            # Chercher 720p pour équilibre qualité/performance
            best_file = None
            for vf in video_files:
                height = vf.get("height", 0)
                if 600 <= height <= 800:
                    best_file = vf
                    break
            
            if not best_file and video_files:
                best_file = min(video_files, key=lambda x: x.get("height", 9999))
            
            if not best_file:
                return None
            
            url = best_file.get("link")
            console.print(f"[blue]Téléchargement vidéo Pexels ({best_file.get('width')}x{best_file.get('height')})...[/blue]")
            
            response = httpx.get(url, timeout=120, follow_redirects=True)
            response.raise_for_status()
            
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(response.content)
            return output_path
            
        except Exception as e:
            console.print(f"[yellow]Erreur téléchargement Pexels: {e}[/yellow]")
            return None


class ScriptSubtitleGenerator:
    """
    Génère les sous-titres DEPUIS LE TEXTE DU SCRIPT (pas de transcription).
    Utilise Whisper uniquement pour les timings, mais garde le texte original.
    """
    
    def __init__(self, model_size: str = "medium"):
        self.model_size = model_size
        self._model = None
    
    @property
    def model(self):
        """Lazy loading du modèle Whisper."""
        if self._model is None:
            console.print(f"[blue]Chargement modèle Whisper ({self.model_size})...[/blue]")
            import whisper
            self._model = whisper.load_model(self.model_size)
        return self._model
    
    def generate(self, audio_path: Path, script: Script) -> Subtitles:
        """
        Génère les sous-titres en utilisant le texte du script.
        
        Process:
        1. Whisper pour obtenir les timings des segments
        2. Remplace le texte transcrit par le texte original du script
        """
        console.print(f"[blue]Synchronisation sous-titres avec le script...[/blue]")
        
        # 1. Obtenir les timings via Whisper
        result = self.model.transcribe(
            str(audio_path),
            language="fr",
            word_timestamps=True,
        )
        
        # 2. Découper le texte du script en segments
        script_text = script.full_text
        script_segments = self._split_text_smart(script_text)
        whisper_segments = result["segments"]
        
        # 3. Mapper les timings Whisper aux segments du script
        segments = self._align_segments(script_segments, whisper_segments)
        
        # 4. Sauvegarder en SRT
        srt_path = settings.output_dir / "subtitles" / f"{script.id}.srt"
        srt_path.parent.mkdir(parents=True, exist_ok=True)
        
        srt_content = self._to_srt(segments)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)
        
        console.print(f"[green]✓ Sous-titres générés (texte original) : {srt_path}[/green]")
        
        return Subtitles(
            id=script.id,
            audio_id=script.id,
            segments=segments,
            srt_path=srt_path,
        )
    
    def _split_text_smart(self, text: str, max_chars: int = 60) -> list[str]:
        """
        Découpe le texte en segments lisibles pour les sous-titres.
        Max ~60 caractères par segment, coupe aux ponctuations.
        """
        # Nettoyer le texte
        text = text.strip()
        
        # Découper aux ponctuations fortes d'abord
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        segments = []
        for sentence in sentences:
            if len(sentence) <= max_chars:
                segments.append(sentence.strip())
            else:
                # Découper aux virgules ou en milieu de phrase
                parts = re.split(r'(?<=[,;:])\s+', sentence)
                current = ""
                for part in parts:
                    if len(current) + len(part) + 1 <= max_chars:
                        current = f"{current} {part}".strip()
                    else:
                        if current:
                            segments.append(current)
                        current = part
                if current:
                    segments.append(current)
        
        return [s for s in segments if s.strip()]
    
    def _align_segments(
        self, 
        script_segments: list[str], 
        whisper_segments: list[dict]
    ) -> list[SubtitleSegment]:
        """
        Aligne les segments du script avec les timings Whisper.
        """
        if not whisper_segments:
            # Fallback: répartir uniformément
            return self._fallback_timing(script_segments, 30.0)
        
        total_duration = whisper_segments[-1]["end"]
        total_script_chars = sum(len(s) for s in script_segments)
        
        aligned = []
        current_time = 0.0
        
        for i, seg_text in enumerate(script_segments):
            # Durée proportionnelle au nombre de caractères
            char_ratio = len(seg_text) / total_script_chars
            duration = char_ratio * total_duration
            
            # Minimum 1.5 sec, maximum 5 sec par segment
            duration = max(1.5, min(5.0, duration))
            
            end_time = min(current_time + duration, total_duration)
            
            aligned.append(SubtitleSegment(
                index=i + 1,
                start_time=current_time,
                end_time=end_time,
                text=seg_text,
            ))
            
            current_time = end_time
        
        return aligned
    
    def _fallback_timing(self, segments: list[str], total_duration: float) -> list[SubtitleSegment]:
        """Timing de secours si Whisper échoue."""
        if not segments:
            return []
        
        duration_per_segment = total_duration / len(segments)
        
        return [
            SubtitleSegment(
                index=i + 1,
                start_time=i * duration_per_segment,
                end_time=(i + 1) * duration_per_segment,
                text=seg,
            )
            for i, seg in enumerate(segments)
        ]
    
    def _to_srt(self, segments: list[SubtitleSegment]) -> str:
        """Convertit les segments en format SRT."""
        lines = []
        for seg in segments:
            start = self._format_timestamp(seg.start_time)
            end = self._format_timestamp(seg.end_time)
            lines.append(f"{seg.index}")
            lines.append(f"{start} --> {end}")
            lines.append(seg.text)
            lines.append("")
        return "\n".join(lines)
    
    @staticmethod
    def _format_timestamp(seconds: float) -> str:
        """Formate les secondes en timestamp SRT."""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


class SubtitleStyler:
    """Génère des sous-titres stylisés format TikTok."""
    
    ASS_HEADER = """[Script Info]
Title: NoRadar TikTok Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial Black,72,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,4,2,2,60,60,400,1
Style: Accent,Arial Black,78,&H0000FFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,5,2,2,60,60,400,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    
    @staticmethod
    def time_to_ass(seconds: float) -> str:
        """Convertit secondes en format ASS."""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        centisecs = int((seconds % 1) * 100)
        return f"{hours}:{minutes:02d}:{secs:02d}.{centisecs:02d}"
    
    @classmethod
    def generate_ass(cls, segments: list[SubtitleSegment], output_path: Path) -> Path:
        """Génère un fichier ASS avec style TikTok."""
        lines = [cls.ASS_HEADER]
        
        for seg in segments:
            start = cls.time_to_ass(seg.start_time)
            end = cls.time_to_ass(seg.end_time)
            
            text = seg.text.strip().upper()
            
            # Couper les lignes longues
            if len(text) > 40:
                words = text.split()
                mid = len(words) // 2
                text = " ".join(words[:mid]) + "\\N" + " ".join(words[mid:])
            
            style = "Accent" if seg.index % 3 == 1 else "Default"
            lines.append(f"Dialogue: 0,{start},{end},{style},,0,0,0,,{text}")
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")
        return output_path


class VideoComposerPro:
    """Compositeur vidéo avec banque locale + Pexels fallback."""
    
    def __init__(self):
        self.pexels = PexelsClient()
        self.temp_dir = settings.temp_dir / "video_work"
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.backgrounds_dir = settings.assets_dir / "backgrounds"
        self.width = settings.video_width
        self.height = settings.video_height
        self._check_ffmpeg()
    
    def _check_ffmpeg(self):
        """Vérifie que FFmpeg est installé."""
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise RuntimeError("FFmpeg n'est pas installé")
    
    def get_background_video(self, format_type: str, duration: float) -> Path:
        """
        Obtient une vidéo de fond :
        1. D'abord cherche dans la banque locale (assets/backgrounds/)
        2. Sinon télécharge depuis Pexels
        3. Sinon génère un dégradé
        """
        # 1. Chercher dans la banque locale
        local_video = self._find_local_video(format_type)
        if local_video:
            console.print(f"[green]✓ Vidéo locale : {local_video.name}[/green]")
            return local_video
        
        # 2. Pexels fallback
        if self.pexels.api_key:
            keywords = PEXELS_KEYWORDS.get(format_type, ["abstract background"])
            query = random.choice(keywords)
            
            console.print(f"[blue]Recherche Pexels: '{query}'...[/blue]")
            videos = self.pexels.search_videos(query)
            
            if videos:
                video = random.choice(videos[:3])
                video_path = self.temp_dir / f"pexels_{video['id']}.mp4"
                
                if not video_path.exists():
                    downloaded = self.pexels.download_video(video, video_path)
                    if downloaded:
                        return downloaded
        
        # 3. Dégradé fallback
        console.print("[yellow]Génération fond dégradé...[/yellow]")
        return self._generate_gradient_background(format_type, duration)
    
    def _find_local_video(self, format_type: str) -> Optional[Path]:
        """Cherche une vidéo dans la banque locale."""
        if not self.backgrounds_dir.exists():
            return None
        
        categories = LOCAL_VIDEO_CATEGORIES.get(format_type, [])
        
        # Chercher les vidéos correspondantes
        candidates = []
        for video_file in self.backgrounds_dir.glob("*.mp4"):
            name_lower = video_file.stem.lower()
            for cat in categories:
                if cat in name_lower:
                    candidates.append(video_file)
                    break
        
        # Si pas de match par catégorie, prendre n'importe quelle vidéo
        if not candidates:
            candidates = list(self.backgrounds_dir.glob("*.mp4"))
        
        if candidates:
            return random.choice(candidates)
        
        return None
    
    def _generate_gradient_background(self, format_type: str, duration: float) -> Path:
        """Génère un fond dégradé animé."""
        output = self.temp_dir / f"gradient_{format_type}.mp4"
        
        colors = GRADIENT_COLORS.get(format_type, ("#1a1a2e", "#16213e"))
        c1 = colors[0].replace("#", "0x")
        
        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi",
            "-i", f"color=c={c1}:s={self.width}x{self.height}:d={duration}",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            str(output)
        ]
        
        subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        return output
    
    def prepare_background(self, bg_path: Path, duration: float) -> Path:
        """Prépare la vidéo de fond (loop, resize, crop)."""
        output = self.temp_dir / "bg_prepared.mp4"
        
        cmd = [
            "ffmpeg", "-y",
            "-stream_loop", "-1",
            "-i", str(bg_path),
            "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height},setsar=1",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "23",
            "-an",
            str(output)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg prepare failed: {result.stderr}")
        
        return output
    
    def compose(
        self,
        script: Script,
        audio: AudioFile,
        subtitles: Subtitles,
        output_path: Path,
        background_image: Optional[Path] = None,
    ) -> Path:
        """Compose la vidéo finale."""
        console.print("[bold blue]🎬 Composition vidéo PRO...[/bold blue]")
        
        duration = audio.duration + 0.5
        
        # 1. Obtenir vidéo de fond
        if background_image and background_image.exists():
            bg_video = self._image_to_video(background_image, duration)
        else:
            bg_video = self.get_background_video(script.format.value, duration)
        
        # 2. Préparer le fond
        console.print("[blue]Préparation fond vidéo...[/blue]")
        prepared_bg = self.prepare_background(bg_video, duration)
        
        # 3. Générer sous-titres ASS
        console.print("[blue]Stylisation sous-titres TikTok...[/blue]")
        ass_path = self.temp_dir / f"{script.id}.ass"
        SubtitleStyler.generate_ass(subtitles.segments, ass_path)
        
        # 4. Assemblage final
        console.print("[blue]Assemblage final...[/blue]")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        ass_path_escaped = str(ass_path).replace("\\", "/").replace(":", "\\:")
        
        cmd = [
            "ffmpeg", "-y",
            "-i", str(prepared_bg),
            "-i", str(audio.path),
            "-filter_complex", f"[0:v]ass='{ass_path_escaped}'[v]",
            "-map", "[v]",
            "-map", "1:a",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "20",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode != 0:
            console.print(f"[yellow]ASS fallback vers SRT...[/yellow]")
            return self._compose_fallback(prepared_bg, audio, subtitles, output_path)
        
        console.print(f"[green]✓ Vidéo générée : {output_path}[/green]")
        return output_path
    
    def _image_to_video(self, image_path: Path, duration: float) -> Path:
        """Convertit une image en vidéo."""
        output = self.temp_dir / "image_bg.mp4"
        
        cmd = [
            "ffmpeg", "-y",
            "-loop", "1",
            "-i", str(image_path),
            "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height}",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            str(output)
        ]
        
        subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        return output
    
    def _compose_fallback(
        self,
        bg_path: Path,
        audio: AudioFile,
        subtitles: Subtitles,
        output_path: Path,
    ) -> Path:
        """Composition de secours avec SRT."""
        srt_path = subtitles.srt_path
        srt_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
        
        subtitle_style = (
            "FontName=Arial Black,"
            "FontSize=60,"
            "PrimaryColour=&H00FFFFFF,"
            "OutlineColour=&H00000000,"
            "Outline=4,"
            "Shadow=2,"
            "MarginV=200"
        )
        
        cmd = [
            "ffmpeg", "-y",
            "-i", str(bg_path),
            "-i", str(audio.path),
            "-vf", f"subtitles='{srt_escaped}':force_style='{subtitle_style}'",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "20",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg fallback failed: {result.stderr}")
        
        console.print(f"[green]✓ Vidéo générée (fallback) : {output_path}[/green]")
        return output_path


class VideoPipeline:
    """Pipeline complet : script → sous-titres (texte original) → vidéo."""
    
    def __init__(self):
        self.subtitle_generator = ScriptSubtitleGenerator()
        self.video_composer = VideoComposerPro()
    
    def process(
        self,
        script: Script,
        audio: AudioFile,
        background_image: Optional[Path] = None,
    ) -> Video:
        """
        Traite un script/audio complet jusqu'à la vidéo finale.
        
        IMPORTANT: Les sous-titres utilisent le TEXTE DU SCRIPT (pas de transcription)
        """
        settings.ensure_directories()
        
        # 1. Générer les sous-titres DEPUIS LE SCRIPT (pas de transcription)
        subtitles = self.subtitle_generator.generate(audio.path, script)
        
        # 2. Composer la vidéo PRO
        video_path = settings.output_dir / "videos" / f"noradar_{script.format.value}_{script.id}.mp4"
        
        self.video_composer.compose(
            script=script,
            audio=audio,
            subtitles=subtitles,
            output_path=video_path,
            background_image=background_image,
        )
        
        # 3. Créer l'objet Video
        video = Video(
            id=script.id,
            script=script,
            audio=audio,
            subtitles=subtitles,
            video_path=video_path,
            status=VideoStatus.VIDEO_READY,
        )
        
        console.print(f"[bold green]✓ Vidéo PRO complète : {video.filename}[/bold green]")
        return video
