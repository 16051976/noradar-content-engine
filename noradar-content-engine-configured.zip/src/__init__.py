"""NoRadar Content Engine - Production automatisée de vidéos marketing."""

__version__ = "2.0.0"
