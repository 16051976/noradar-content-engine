"""
Orchestrateur du pipeline de production vidéo.
"""

from datetime import datetime
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from src.config import settings
from src.models import (
    BatchJob,
    Script,
    Video,
    VideoFormat,
    VideoStatus,
    WeeklyPlan,
)
from src.scripts.generator import ScriptGenerator
from src.voice.generator import VoiceGenerator
from src.video.composer import VideoPipeline
from src.storage.gdrive import GoogleDriveSync

console = Console()


class ContentOrchestrator:
    """Orchestre le pipeline complet de production."""

    def __init__(self):
        self.script_generator = ScriptGenerator()
        self.voice_generator = VoiceGenerator()
        self.video_pipeline = VideoPipeline()
        self._gdrive = None

    @property
    def gdrive(self) -> GoogleDriveSync:
        """Lazy loading de Google Drive."""
        if self._gdrive is None:
            self._gdrive = GoogleDriveSync()
        return self._gdrive

    def produce_video(
        self,
        format: VideoFormat,
        theme: Optional[str] = None,
        background_image: Optional[Path] = None,
        upload: bool = False,
    ) -> Video:
        """
        Produit une vidéo complète de A à Z.

        Args:
            format: Format de vidéo
            theme: Thème optionnel
            background_image: Image de fond optionnelle
            upload: Si True, upload vers Google Drive

        Returns:
            Video complète
        """
        console.print(f"\n[bold blue]═══ Production vidéo {format.value.upper()} ═══[/bold blue]\n")

        # 1. Génération du script
        console.print("[bold]1/4 - Génération du script[/bold]")
        script = self.script_generator.generate(format, theme)
        self.script_generator.save_script(script)

        # 2. Génération de la voix
        console.print("\n[bold]2/4 - Génération de la voix[/bold]")
        audio = self.voice_generator.generate_from_script(script)

        # 3. Composition de la vidéo
        console.print("\n[bold]3/4 - Composition de la vidéo[/bold]")
        video = self.video_pipeline.process(script, audio, background_image)

        # 4. Upload optionnel
        if upload:
            console.print("\n[bold]4/4 - Upload Google Drive[/bold]")
            self.gdrive.upload_video(video)
        else:
            console.print("\n[dim]4/4 - Upload ignoré (--no-upload)[/dim]")

        # Copier vers ready/ pour Repurpose.io
        self._copy_to_ready(video)

        console.print(f"\n[bold green]✓ Production terminée : {video.filename}[/bold green]")
        return video

    def produce_batch(
        self,
        distribution: dict[VideoFormat, int],
        theme: Optional[str] = None,
        upload: bool = False,
    ) -> BatchJob:
        """
        Produit un batch de vidéos selon la distribution.

        Args:
            distribution: {format: nombre} ex: {SCANDALE: 5, TUTO: 3}
            theme: Thème optionnel
            upload: Si True, upload vers Google Drive

        Returns:
            BatchJob avec toutes les vidéos
        """
        total = sum(distribution.values())
        console.print(f"\n[bold blue]═══ Production batch : {total} vidéos ═══[/bold blue]\n")

        batch = BatchJob(total_count=total)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task("Production...", total=total)

            for format, count in distribution.items():
                for i in range(count):
                    try:
                        video = self.produce_video(
                            format=format,
                            theme=theme,
                            upload=upload,
                        )
                        batch.videos.append(video)
                        batch.completed_count += 1
                    except Exception as e:
                        console.print(f"[red]Erreur {format.value} #{i + 1}: {e}[/red]")
                        batch.failed_count += 1

                    progress.update(task, advance=1)

        batch.completed_at = datetime.now()

        console.print(f"\n[bold green]Batch terminé :[/bold green]")
        console.print(f"  ✓ Réussies : {batch.completed_count}")
        console.print(f"  ✗ Échouées : {batch.failed_count}")

        return batch

    def produce_weekly(
        self,
        plan: Optional[WeeklyPlan] = None,
        upload: bool = True,
    ) -> WeeklyPlan:
        """
        Produit le contenu d'une semaine complète.

        Args:
            plan: Plan de production (défaut: 30 vidéos réparties)
            upload: Si True, upload vers Google Drive

        Returns:
            WeeklyPlan avec tous les batches
        """
        if plan is None:
            now = datetime.now()
            plan = WeeklyPlan(
                week_number=now.isocalendar()[1],
                year=now.year,
            )

        console.print(f"\n[bold blue]═══ Production semaine {plan.week_number}/{plan.year} ═══[/bold blue]")
        console.print(f"[dim]Objectif : {plan.target_count} vidéos[/dim]\n")

        # Production en batches de 5
        remaining = dict(plan.distribution)
        batch_size = settings.batch_size

        while sum(remaining.values()) > 0:
            # Préparer le batch
            batch_distribution = {}
            count = 0

            for format in remaining:
                if remaining[format] > 0 and count < batch_size:
                    take = min(remaining[format], batch_size - count)
                    batch_distribution[format] = take
                    remaining[format] -= take
                    count += take

            if batch_distribution:
                batch = self.produce_batch(batch_distribution, upload=upload)
                plan.batches.append(batch)

        console.print(f"\n[bold green]═══ Semaine terminée ═══[/bold green]")
        total_done = sum(b.completed_count for b in plan.batches)
        console.print(f"Total produit : {total_done}/{plan.target_count} vidéos")

        return plan

    def _copy_to_ready(self, video: Video) -> Path:
        """Copie la vidéo vers le dossier ready/ pour Repurpose.io."""
        if not video.video_path or not video.video_path.exists():
            return None

        ready_dir = settings.output_dir / "ready"
        ready_dir.mkdir(exist_ok=True)

        dest_path = ready_dir / video.filename
        import shutil

        shutil.copy2(video.video_path, dest_path)
        console.print(f"[dim]Copié vers ready/ : {video.filename}[/dim]")
        return dest_path

    def script_only(
        self,
        format: VideoFormat,
        theme: Optional[str] = None,
    ) -> Script:
        """Génère uniquement un script (pour test/preview)."""
        script = self.script_generator.generate(format, theme)
        self.script_generator.save_script(script)

        console.print(f"\n[bold]Script généré :[/bold]")
        console.print(f"[yellow]HOOK:[/yellow] {script.hook}")
        console.print(f"[yellow]BODY:[/yellow] {script.body[:200]}...")
        console.print(f"[yellow]CTA:[/yellow] {script.cta}")
        console.print(f"[dim]Durée estimée : {script.duration_estimate}s[/dim]")

        return script


def quick_produce(format: str, theme: Optional[str] = None, upload: bool = False) -> Video:
    """Fonction utilitaire pour production rapide."""
    orchestrator = ContentOrchestrator()
    video_format = VideoFormat(format.lower())
    return orchestrator.produce_video(video_format, theme, upload=upload)
