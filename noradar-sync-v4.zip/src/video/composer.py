"""
Compositeur vidéo PRO avec :
- Sous-titres synchronisés précisément (timings Whisper mot par mot + texte du script)
- Banque de vidéos locales pré-sélectionnées (ou Pexels en fallback)
- Style TikTok optimisé
"""

import os
import random
import subprocess
import re
from pathlib import Path
from typing import Optional
import httpx
from rich.console import Console

from src.config import settings
from src.models import AudioFile, Script, SubtitleSegment, Subtitles, Video, VideoStatus

console = Console()


# === BANQUE DE VIDÉOS LOCALES ===
LOCAL_VIDEO_CATEGORIES = {
    "scandale": ["road", "highway", "traffic", "radar"],
    "tuto": ["document", "paper", "phone", "desk"],
    "temoignage": ["happy", "relief", "car", "driver"],
    "mythe": ["thinking", "question", "idea"],
    "chiffre_choc": ["money", "euro", "wallet", "cash"],
}

PEXELS_KEYWORDS = {
    "scandale": ["car driving highway", "speed limit road", "traffic city"],
    "tuto": ["writing document", "paperwork office", "smartphone typing"],
    "temoignage": ["happy person relief", "good news reaction", "stress free"],
    "mythe": ["thinking person", "question mark", "idea concept"],
    "chiffre_choc": ["euro money", "wallet cash", "counting bills"],
}

GRADIENT_COLORS = {
    "scandale": ("#FF4B4B", "#8B0000"),
    "tuto": ("#4ECDC4", "#1A535C"),
    "temoignage": ("#45B7D1", "#1E3A5F"),
    "mythe": ("#9B59B6", "#4A235A"),
    "chiffre_choc": ("#F39C12", "#7D4E00"),
}


class PexelsClient:
    """Client pour télécharger des vidéos de fond depuis Pexels."""
    
    BASE_URL = "https://api.pexels.com/videos/search"
    
    def __init__(self):
        self.api_key = os.getenv("PEXELS_API_KEY", "")
    
    def search_videos(self, query: str, orientation: str = "portrait", per_page: int = 5) -> list[dict]:
        if not self.api_key:
            return []
        try:
            response = httpx.get(
                self.BASE_URL,
                params={"query": query, "orientation": orientation, "per_page": per_page, "size": "medium"},
                headers={"Authorization": self.api_key},
                timeout=15,
            )
            response.raise_for_status()
            return response.json().get("videos", [])
        except Exception as e:
            console.print(f"[yellow]Pexels API error: {e}[/yellow]")
            return []
    
    def download_video(self, video_data: dict, output_path: Path) -> Optional[Path]:
        try:
            video_files = video_data.get("video_files", [])
            best_file = None
            for vf in video_files:
                height = vf.get("height", 0)
                if 600 <= height <= 800:
                    best_file = vf
                    break
            if not best_file and video_files:
                best_file = min(video_files, key=lambda x: x.get("height", 9999))
            if not best_file:
                return None
            
            url = best_file.get("link")
            console.print(f"[blue]Téléchargement Pexels ({best_file.get('width')}x{best_file.get('height')})...[/blue]")
            response = httpx.get(url, timeout=120, follow_redirects=True)
            response.raise_for_status()
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(response.content)
            return output_path
        except Exception as e:
            console.print(f"[yellow]Erreur téléchargement Pexels: {e}[/yellow]")
            return None


class PreciseSyncSubtitleGenerator:
    """
    Génère les sous-titres avec synchronisation PRÉCISE.
    
    Méthode :
    1. Whisper transcrit avec timings mot par mot
    2. On découpe le texte du script en segments
    3. On aligne chaque segment aux timings Whisper correspondants
    """
    
    def __init__(self, model_size: str = "medium"):
        self.model_size = model_size
        self._model = None
    
    @property
    def model(self):
        if self._model is None:
            console.print(f"[blue]Chargement Whisper ({self.model_size})...[/blue]")
            import whisper
            self._model = whisper.load_model(self.model_size)
        return self._model
    
    def generate(self, audio_path: Path, script: Script) -> Subtitles:
        """Génère les sous-titres synchronisés précisément."""
        console.print(f"[blue]Synchronisation précise des sous-titres...[/blue]")
        
        # 1. Transcrire avec Whisper (timings mot par mot)
        result = self.model.transcribe(
            str(audio_path),
            language="fr",
            word_timestamps=True,
        )
        
        # 2. Extraire tous les mots avec leurs timings
        all_words = []
        for seg in result["segments"]:
            if "words" in seg:
                for w in seg["words"]:
                    all_words.append({
                        "word": w["word"].strip(),
                        "start": w["start"],
                        "end": w["end"],
                    })
        
        if not all_words:
            console.print("[yellow]Pas de timings mot par mot, fallback...[/yellow]")
            return self._fallback_generate(audio_path, script, result)
        
        # 3. Découper le script en segments lisibles
        script_segments = self._split_script(script.full_text)
        
        # 4. Aligner chaque segment du script aux timings Whisper
        aligned_segments = self._align_to_words(script_segments, all_words)
        
        # 5. Sauvegarder en SRT
        srt_path = settings.output_dir / "subtitles" / f"{script.id}.srt"
        srt_path.parent.mkdir(parents=True, exist_ok=True)
        srt_content = self._to_srt(aligned_segments)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)
        
        console.print(f"[green]✓ Sous-titres synchronisés : {srt_path}[/green]")
        
        return Subtitles(
            id=script.id,
            audio_id=script.id,
            segments=aligned_segments,
            srt_path=srt_path,
        )
    
    def _split_script(self, text: str, max_chars: int = 50) -> list[str]:
        """Découpe le script en segments de ~50 caractères aux ponctuations."""
        text = text.strip()
        
        # D'abord découper aux phrases
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        segments = []
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            if len(sentence) <= max_chars:
                segments.append(sentence)
            else:
                # Découper aux virgules/points-virgules
                parts = re.split(r'(?<=[,;:])\s+', sentence)
                current = ""
                for part in parts:
                    if len(current) + len(part) + 1 <= max_chars:
                        current = f"{current} {part}".strip()
                    else:
                        if current:
                            segments.append(current)
                        # Si la partie est encore trop longue, découper aux mots
                        if len(part) > max_chars:
                            words = part.split()
                            current = ""
                            for word in words:
                                if len(current) + len(word) + 1 <= max_chars:
                                    current = f"{current} {word}".strip()
                                else:
                                    if current:
                                        segments.append(current)
                                    current = word
                        else:
                            current = part
                if current:
                    segments.append(current)
        
        return [s.strip() for s in segments if s.strip()]
    
    def _normalize(self, text: str) -> str:
        """Normalise le texte pour la comparaison."""
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)  # Enlever ponctuation
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def _align_to_words(self, script_segments: list[str], words: list[dict]) -> list[SubtitleSegment]:
        """
        Aligne chaque segment du script aux mots Whisper.
        
        Pour chaque segment :
        1. Trouver les premiers mots correspondants dans la transcription
        2. Utiliser leur timing comme début
        3. Continuer jusqu'à la fin du segment
        """
        aligned = []
        word_index = 0
        total_words = len(words)
        
        for seg_idx, seg_text in enumerate(script_segments):
            seg_words = self._normalize(seg_text).split()
            if not seg_words:
                continue
            
            # Chercher le premier mot du segment dans les mots Whisper
            start_time = None
            end_time = None
            
            # Chercher à partir de word_index
            search_start = word_index
            found = False
            
            for i in range(search_start, min(search_start + 30, total_words)):
                whisper_word = self._normalize(words[i]["word"])
                first_seg_word = seg_words[0]
                
                # Match si le mot commence pareil (tolérance pour accents/transcription)
                if whisper_word.startswith(first_seg_word[:3]) or first_seg_word.startswith(whisper_word[:3]):
                    start_time = words[i]["start"]
                    
                    # Trouver la fin : avancer du nombre de mots du segment
                    end_idx = min(i + len(seg_words), total_words - 1)
                    end_time = words[end_idx]["end"]
                    
                    word_index = end_idx + 1
                    found = True
                    break
            
            # Fallback si pas trouvé
            if not found:
                if aligned:
                    # Continuer après le dernier segment
                    start_time = aligned[-1].end_time
                    # Estimer la durée
                    duration = len(seg_text) * 0.05  # ~50ms par caractère
                    end_time = start_time + max(1.5, min(4.0, duration))
                else:
                    start_time = 0.0
                    end_time = 2.0
            
            # S'assurer que end > start
            if end_time <= start_time:
                end_time = start_time + 1.5
            
            aligned.append(SubtitleSegment(
                index=seg_idx + 1,
                start_time=start_time,
                end_time=end_time,
                text=seg_text,
            ))
        
        return aligned
    
    def _fallback_generate(self, audio_path: Path, script: Script, whisper_result: dict) -> Subtitles:
        """Fallback si pas de word timestamps."""
        segments = whisper_result.get("segments", [])
        total_duration = segments[-1]["end"] if segments else 30.0
        
        script_segments = self._split_script(script.full_text)
        duration_per_seg = total_duration / len(script_segments) if script_segments else 3.0
        
        aligned = []
        for i, seg_text in enumerate(script_segments):
            aligned.append(SubtitleSegment(
                index=i + 1,
                start_time=i * duration_per_seg,
                end_time=(i + 1) * duration_per_seg,
                text=seg_text,
            ))
        
        srt_path = settings.output_dir / "subtitles" / f"{script.id}.srt"
        srt_path.parent.mkdir(parents=True, exist_ok=True)
        srt_content = self._to_srt(aligned)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)
        
        return Subtitles(id=script.id, audio_id=script.id, segments=aligned, srt_path=srt_path)
    
    def _to_srt(self, segments: list[SubtitleSegment]) -> str:
        lines = []
        for seg in segments:
            start = self._format_timestamp(seg.start_time)
            end = self._format_timestamp(seg.end_time)
            lines.extend([f"{seg.index}", f"{start} --> {end}", seg.text, ""])
        return "\n".join(lines)
    
    @staticmethod
    def _format_timestamp(seconds: float) -> str:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


class SubtitleStyler:
    """Génère des sous-titres stylisés format TikTok."""
    
    ASS_HEADER = """[Script Info]
Title: NoRadar TikTok Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial Black,72,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,4,2,2,60,60,400,1
Style: Accent,Arial Black,78,&H0000FFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,5,2,2,60,60,400,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    
    @staticmethod
    def time_to_ass(seconds: float) -> str:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        centisecs = int((seconds % 1) * 100)
        return f"{hours}:{minutes:02d}:{secs:02d}.{centisecs:02d}"
    
    @classmethod
    def generate_ass(cls, segments: list[SubtitleSegment], output_path: Path) -> Path:
        lines = [cls.ASS_HEADER]
        for seg in segments:
            start = cls.time_to_ass(seg.start_time)
            end = cls.time_to_ass(seg.end_time)
            text = seg.text.strip().upper()
            if len(text) > 40:
                words = text.split()
                mid = len(words) // 2
                text = " ".join(words[:mid]) + "\\N" + " ".join(words[mid:])
            style = "Accent" if seg.index % 3 == 1 else "Default"
            lines.append(f"Dialogue: 0,{start},{end},{style},,0,0,0,,{text}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")
        return output_path


class VideoComposerPro:
    """Compositeur vidéo avec banque locale + Pexels fallback."""
    
    def __init__(self):
        self.pexels = PexelsClient()
        self.temp_dir = settings.temp_dir / "video_work"
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.backgrounds_dir = settings.assets_dir / "backgrounds"
        self.width = settings.video_width
        self.height = settings.video_height
        self._check_ffmpeg()
    
    def _check_ffmpeg(self):
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise RuntimeError("FFmpeg n'est pas installé")
    
    def get_background_video(self, format_type: str, duration: float) -> Path:
        # 1. Banque locale
        local_video = self._find_local_video(format_type)
        if local_video:
            console.print(f"[green]✓ Vidéo locale : {local_video.name}[/green]")
            return local_video
        
        # 2. Pexels
        if self.pexels.api_key:
            keywords = PEXELS_KEYWORDS.get(format_type, ["abstract background"])
            query = random.choice(keywords)
            console.print(f"[blue]Recherche Pexels: '{query}'...[/blue]")
            videos = self.pexels.search_videos(query)
            if videos:
                video = random.choice(videos[:3])
                video_path = self.temp_dir / f"pexels_{video['id']}.mp4"
                if not video_path.exists():
                    downloaded = self.pexels.download_video(video, video_path)
                    if downloaded:
                        return downloaded
        
        # 3. Dégradé
        console.print("[yellow]Génération fond dégradé...[/yellow]")
        return self._generate_gradient_background(format_type, duration)
    
    def _find_local_video(self, format_type: str) -> Optional[Path]:
        if not self.backgrounds_dir.exists():
            return None
        categories = LOCAL_VIDEO_CATEGORIES.get(format_type, [])
        candidates = []
        for video_file in self.backgrounds_dir.glob("*.mp4"):
            name_lower = video_file.stem.lower()
            for cat in categories:
                if cat in name_lower:
                    candidates.append(video_file)
                    break
        if not candidates:
            candidates = list(self.backgrounds_dir.glob("*.mp4"))
        return random.choice(candidates) if candidates else None
    
    def _generate_gradient_background(self, format_type: str, duration: float) -> Path:
        output = self.temp_dir / f"gradient_{format_type}.mp4"
        colors = GRADIENT_COLORS.get(format_type, ("#1a1a2e", "#16213e"))
        c1 = colors[0].replace("#", "0x")
        cmd = [
            "ffmpeg", "-y", "-f", "lavfi",
            "-i", f"color=c={c1}:s={self.width}x{self.height}:d={duration}",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", str(output)
        ]
        subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        return output
    
    def prepare_background(self, bg_path: Path, duration: float) -> Path:
        output = self.temp_dir / "bg_prepared.mp4"
        cmd = [
            "ffmpeg", "-y", "-stream_loop", "-1", "-i", str(bg_path),
            "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height},setsar=1",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-an", str(output)
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg prepare failed: {result.stderr}")
        return output
    
    def compose(self, script: Script, audio: AudioFile, subtitles: Subtitles, output_path: Path, background_image: Optional[Path] = None) -> Path:
        console.print("[bold blue]🎬 Composition vidéo PRO...[/bold blue]")
        duration = audio.duration + 0.5
        
        if background_image and background_image.exists():
            bg_video = self._image_to_video(background_image, duration)
        else:
            bg_video = self.get_background_video(script.format.value, duration)
        
        console.print("[blue]Préparation fond vidéo...[/blue]")
        prepared_bg = self.prepare_background(bg_video, duration)
        
        console.print("[blue]Stylisation sous-titres TikTok...[/blue]")
        ass_path = self.temp_dir / f"{script.id}.ass"
        SubtitleStyler.generate_ass(subtitles.segments, ass_path)
        
        console.print("[blue]Assemblage final...[/blue]")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        ass_path_escaped = str(ass_path).replace("\\", "/").replace(":", "\\:")
        
        cmd = [
            "ffmpeg", "-y", "-i", str(prepared_bg), "-i", str(audio.path),
            "-filter_complex", f"[0:v]ass='{ass_path_escaped}'[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            console.print(f"[yellow]ASS fallback vers SRT...[/yellow]")
            return self._compose_fallback(prepared_bg, audio, subtitles, output_path)
        
        console.print(f"[green]✓ Vidéo générée : {output_path}[/green]")
        return output_path
    
    def _image_to_video(self, image_path: Path, duration: float) -> Path:
        output = self.temp_dir / "image_bg.mp4"
        cmd = [
            "ffmpeg", "-y", "-loop", "1", "-i", str(image_path), "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height}",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", str(output)
        ]
        subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        return output
    
    def _compose_fallback(self, bg_path: Path, audio: AudioFile, subtitles: Subtitles, output_path: Path) -> Path:
        srt_path = subtitles.srt_path
        srt_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
        subtitle_style = "FontName=Arial Black,FontSize=60,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=4,Shadow=2,MarginV=200"
        cmd = [
            "ffmpeg", "-y", "-i", str(bg_path), "-i", str(audio.path),
            "-vf", f"subtitles='{srt_escaped}':force_style='{subtitle_style}'",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
            str(output_path)
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg fallback failed: {result.stderr}")
        console.print(f"[green]✓ Vidéo générée (fallback) : {output_path}[/green]")
        return output_path


class VideoPipeline:
    """Pipeline complet avec synchronisation précise."""
    
    def __init__(self):
        self.subtitle_generator = PreciseSyncSubtitleGenerator()
        self.video_composer = VideoComposerPro()
    
    def process(self, script: Script, audio: AudioFile, background_image: Optional[Path] = None) -> Video:
        settings.ensure_directories()
        
        # 1. Sous-titres synchronisés précisément
        subtitles = self.subtitle_generator.generate(audio.path, script)
        
        # 2. Composer la vidéo
        video_path = settings.output_dir / "videos" / f"noradar_{script.format.value}_{script.id}.mp4"
        self.video_composer.compose(script=script, audio=audio, subtitles=subtitles, output_path=video_path, background_image=background_image)
        
        # 3. Créer l'objet Video
        video = Video(
            id=script.id, script=script, audio=audio, subtitles=subtitles,
            video_path=video_path, status=VideoStatus.VIDEO_READY,
        )
        console.print(f"[bold green]✓ Vidéo PRO complète : {video.filename}[/bold green]")
        return video
