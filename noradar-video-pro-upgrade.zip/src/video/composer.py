"""
Compositeur vidéo PRO avec Pexels + sous-titres stylisés TikTok.
Génère des vidéos verticales 1080x1920 prêtes pour TikTok/Reels/Shorts.
"""

import os
import random
import subprocess
from pathlib import Path
from typing import Optional
import httpx
from rich.console import Console

from src.config import settings
from src.models import AudioFile, Script, SubtitleSegment, Subtitles, Video, VideoStatus

console = Console()


# Mots-clés Pexels selon le format de vidéo
PEXELS_KEYWORDS = {
    "scandale": ["traffic car", "highway driving", "city traffic", "speed car", "road driving"],
    "tuto": ["smartphone hand", "typing laptop", "documents desk", "writing paper", "phone screen"],
    "temoignage": ["happy person", "thumbs up", "celebration", "smile face", "success"],
    "mythe": ["question thinking", "idea lightbulb", "confused person", "doubt", "mystery"],
    "chiffre_choc": ["money euro", "calculator", "statistics graph", "numbers", "finance"],
}

# Couleurs de fond dégradé par format (fallback si Pexels indisponible)
GRADIENT_COLORS = {
    "scandale": ("#FF4B4B", "#8B0000"),  # Rouge
    "tuto": ("#4ECDC4", "#1A535C"),       # Turquoise
    "temoignage": ("#45B7D1", "#1E3A5F"), # Bleu
    "mythe": ("#9B59B6", "#4A235A"),      # Violet
    "chiffre_choc": ("#F39C12", "#7D4E00"), # Orange
}


class PexelsClient:
    """Client pour télécharger des vidéos de fond depuis Pexels (gratuit)."""
    
    BASE_URL = "https://api.pexels.com/videos/search"
    
    def __init__(self):
        self.api_key = os.getenv("PEXELS_API_KEY", "")
        if not self.api_key:
            console.print("[yellow]⚠ PEXELS_API_KEY non configuré - utilisation fond dégradé[/yellow]")
    
    def search_videos(self, query: str, orientation: str = "portrait", per_page: int = 10) -> list[dict]:
        """Recherche des vidéos sur Pexels."""
        if not self.api_key:
            return []
        
        try:
            response = httpx.get(
                self.BASE_URL,
                params={
                    "query": query,
                    "orientation": orientation,
                    "per_page": per_page,
                    "size": "medium",
                },
                headers={"Authorization": self.api_key},
                timeout=15,
            )
            response.raise_for_status()
            return response.json().get("videos", [])
        except Exception as e:
            console.print(f"[yellow]Pexels API error: {e}[/yellow]")
            return []
    
    def download_video(self, video_data: dict, output_path: Path) -> Optional[Path]:
        """Télécharge une vidéo Pexels en qualité HD."""
        try:
            video_files = video_data.get("video_files", [])
            
            # Chercher la meilleure qualité (720p ou plus, format vertical de préférence)
            best_file = None
            for vf in sorted(video_files, key=lambda x: x.get("height", 0), reverse=True):
                if vf.get("height", 0) >= 720:
                    best_file = vf
                    break
            
            if not best_file and video_files:
                best_file = video_files[0]
            
            if not best_file:
                return None
            
            url = best_file.get("link")
            console.print(f"[blue]Téléchargement vidéo Pexels ({best_file.get('width')}x{best_file.get('height')})...[/blue]")
            
            response = httpx.get(url, timeout=120, follow_redirects=True)
            response.raise_for_status()
            
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(response.content)
            return output_path
            
        except Exception as e:
            console.print(f"[yellow]Erreur téléchargement Pexels: {e}[/yellow]")
            return None


class SubtitleStyler:
    """Génère des sous-titres stylisés format TikTok (gros, centrés, animés)."""
    
    # Header ASS pour sous-titres TikTok style
    ASS_HEADER = """[Script Info]
Title: NoRadar TikTok Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial Black,80,&H00FFFFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,5,3,2,60,60,350,1
Style: Accent,Arial Black,90,&H0000FFFF,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,6,3,2,60,60,350,1
Style: Impact,Arial Black,95,&H0000FF00,&H000000FF,&H00000000,&HAA000000,-1,0,0,0,100,100,0,0,1,6,4,2,60,60,350,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    
    @staticmethod
    def time_to_ass(seconds: float) -> str:
        """Convertit secondes en format ASS (H:MM:SS.cc)."""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        centisecs = int((seconds % 1) * 100)
        return f"{hours}:{minutes:02d}:{secs:02d}.{centisecs:02d}"
    
    @classmethod
    def generate_ass(cls, segments: list[SubtitleSegment], output_path: Path) -> Path:
        """Génère un fichier ASS avec style TikTok viral."""
        lines = [cls.ASS_HEADER]
        
        for seg in segments:
            start = cls.time_to_ass(seg.start_time)
            end = cls.time_to_ass(seg.end_time)
            
            # Nettoyer et formater le texte
            text = seg.text.strip()
            
            # Mettre en MAJUSCULES pour impact TikTok
            text = text.upper()
            
            # Couper les lignes trop longues (max ~35 caractères par ligne)
            if len(text) > 35:
                words = text.split()
                mid = len(words) // 2
                text = " ".join(words[:mid]) + "\\N" + " ".join(words[mid:])
            
            # Alterner les styles pour dynamisme
            if seg.index % 4 == 1:
                style = "Accent"  # Jaune
            elif seg.index % 4 == 3:
                style = "Impact"  # Vert
            else:
                style = "Default"  # Blanc
            
            lines.append(f"Dialogue: 0,{start},{end},{style},,0,0,0,,{text}")
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")
        return output_path


class SubtitleGenerator:
    """Génère les sous-titres avec timing via Whisper."""
    
    def __init__(self, model_size: str = "base"):
        self.model_size = model_size
        self._model = None
    
    @property
    def model(self):
        """Lazy loading du modèle Whisper."""
        if self._model is None:
            console.print(f"[blue]Chargement modèle Whisper ({self.model_size})...[/blue]")
            import whisper
            self._model = whisper.load_model(self.model_size)
        return self._model
    
    def generate(self, audio_path: Path, script_id: str) -> Subtitles:
        """Génère les sous-titres avec timing pour un fichier audio."""
        console.print(f"[blue]Transcription Whisper : {audio_path.name}...[/blue]")
        
        result = self.model.transcribe(
            str(audio_path),
            language="fr",
            word_timestamps=True,
        )
        
        segments = []
        for i, segment in enumerate(result["segments"]):
            segments.append(
                SubtitleSegment(
                    index=i + 1,
                    start_time=segment["start"],
                    end_time=segment["end"],
                    text=segment["text"].strip(),
                )
            )
        
        # Génération du fichier SRT (backup)
        srt_path = settings.output_dir / "subtitles" / f"{script_id}.srt"
        srt_path.parent.mkdir(parents=True, exist_ok=True)
        
        srt_content = self._to_srt(segments)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)
        
        console.print(f"[green]✓ Sous-titres générés : {srt_path}[/green]")
        
        return Subtitles(
            id=script_id,
            audio_id=script_id,
            segments=segments,
            srt_path=srt_path,
        )
    
    def _to_srt(self, segments: list[SubtitleSegment]) -> str:
        """Convertit les segments en format SRT."""
        lines = []
        for seg in segments:
            start = self._format_timestamp(seg.start_time)
            end = self._format_timestamp(seg.end_time)
            lines.append(f"{seg.index}")
            lines.append(f"{start} --> {end}")
            lines.append(seg.text)
            lines.append("")
        return "\n".join(lines)
    
    @staticmethod
    def _format_timestamp(seconds: float) -> str:
        """Formate les secondes en timestamp SRT (HH:MM:SS,mmm)."""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


class VideoComposerPro:
    """Compositeur vidéo professionnel avec Pexels + sous-titres TikTok."""
    
    def __init__(self):
        self.pexels = PexelsClient()
        self.temp_dir = settings.temp_dir / "video_work"
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.width = settings.video_width
        self.height = settings.video_height
        self._check_ffmpeg()
    
    def _check_ffmpeg(self):
        """Vérifie que FFmpeg est installé."""
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise RuntimeError("FFmpeg n'est pas installé. Installez-le avec: apt install ffmpeg")
    
    def get_background_video(self, format_type: str, duration: float) -> Path:
        """Obtient une vidéo de fond depuis Pexels ou génère un dégradé."""
        keywords = PEXELS_KEYWORDS.get(format_type, ["abstract motion", "background loop"])
        query = random.choice(keywords)
        
        console.print(f"[blue]Recherche vidéo Pexels: '{query}'...[/blue]")
        videos = self.pexels.search_videos(query)
        
        if videos:
            # Prendre une vidéo au hasard parmi les résultats
            video = random.choice(videos[:5])  # Top 5 pour qualité
            video_path = self.temp_dir / f"pexels_{video['id']}.mp4"
            
            if not video_path.exists():
                downloaded = self.pexels.download_video(video, video_path)
                if downloaded:
                    console.print(f"[green]✓ Vidéo Pexels téléchargée[/green]")
                    return downloaded
        
        # Fallback: générer un fond dégradé animé
        console.print("[yellow]Pexels indisponible - génération fond dégradé...[/yellow]")
        return self._generate_gradient_background(format_type, duration)
    
    def _generate_gradient_background(self, format_type: str, duration: float) -> Path:
        """Génère un fond dégradé animé selon le format."""
        output = self.temp_dir / f"gradient_{format_type}.mp4"
        
        # Couleurs selon le format
        colors = GRADIENT_COLORS.get(format_type, ("#1a1a2e", "#16213e"))
        c1 = colors[0].replace("#", "0x")
        c2 = colors[1].replace("#", "0x")
        
        # Essayer un dégradé animé
        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi",
            "-i", f"color=c={c1}:s={self.width}x{self.height}:d={duration}",
            "-vf", f"geq=r='128+127*sin(2*PI*T/5)':g='50+50*sin(2*PI*T/7)':b='100+100*sin(2*PI*T/3)'",
            "-t", str(duration),
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            str(output)
        ]
        
        try:
            subprocess.run(cmd, capture_output=True, check=True, timeout=60)
            return output
        except:
            # Fallback: fond uni simple
            cmd = [
                "ffmpeg", "-y",
                "-f", "lavfi",
                "-i", f"color=c={c1}:s={self.width}x{self.height}:d={duration}",
                "-c:v", "libx264",
                "-pix_fmt", "yuv420p",
                str(output)
            ]
            subprocess.run(cmd, capture_output=True, check=True, timeout=60)
            return output
    
    def prepare_background(self, bg_path: Path, duration: float) -> Path:
        """Prépare la vidéo de fond (loop, resize, crop pour format vertical)."""
        output = self.temp_dir / "bg_prepared.mp4"
        
        # Resize et crop pour format vertical 1080x1920
        cmd = [
            "ffmpeg", "-y",
            "-stream_loop", "-1",  # Loop infini
            "-i", str(bg_path),
            "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height},setsar=1",
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "23",
            "-an",  # Pas d'audio
            str(output)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            console.print(f"[red]Erreur préparation fond: {result.stderr}[/red]")
            raise RuntimeError(f"FFmpeg prepare failed: {result.stderr}")
        
        return output
    
    def compose(
        self,
        script: Script,
        audio: AudioFile,
        subtitles: Subtitles,
        output_path: Path,
        background_image: Optional[Path] = None,
    ) -> Path:
        """Compose la vidéo finale avec fond Pexels + sous-titres TikTok."""
        console.print("[bold blue]🎬 Composition vidéo PRO...[/bold blue]")
        
        duration = audio.duration + 0.5  # Petite marge
        
        # 1. Obtenir vidéo de fond
        if background_image and background_image.exists():
            # Utiliser l'image fournie
            bg_video = self._image_to_video(background_image, duration)
        else:
            # Télécharger depuis Pexels
            bg_video = self.get_background_video(script.format.value, duration)
        
        # 2. Préparer le fond (resize, loop, crop)
        console.print("[blue]Préparation fond vidéo...[/blue]")
        prepared_bg = self.prepare_background(bg_video, duration)
        
        # 3. Générer sous-titres ASS (style TikTok)
        console.print("[blue]Génération sous-titres TikTok...[/blue]")
        ass_path = self.temp_dir / f"{script.id}.ass"
        SubtitleStyler.generate_ass(subtitles.segments, ass_path)
        
        # 4. Assemblage final : fond + audio + sous-titres
        console.print("[blue]Assemblage final...[/blue]")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Escape le chemin ASS pour FFmpeg (Windows compatibility)
        ass_path_escaped = str(ass_path).replace("\\", "/").replace(":", "\\:")
        
        cmd = [
            "ffmpeg", "-y",
            "-i", str(prepared_bg),
            "-i", str(audio.path),
            "-filter_complex", f"[0:v]ass='{ass_path_escaped}'[v]",
            "-map", "[v]",
            "-map", "1:a",
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "20",  # Bonne qualité
            "-c:a", "aac",
            "-b:a", "192k",  # Audio qualité
            "-shortest",
            "-movflags", "+faststart",  # Optimisation streaming
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode != 0:
            console.print(f"[red]Erreur FFmpeg: {result.stderr}[/red]")
            # Fallback: essayer sans le filtre ASS complexe
            return self._compose_fallback(prepared_bg, audio, subtitles, output_path)
        
        console.print(f"[green]✓ Vidéo générée : {output_path}[/green]")
        return output_path
    
    def _image_to_video(self, image_path: Path, duration: float) -> Path:
        """Convertit une image en vidéo."""
        output = self.temp_dir / "image_bg.mp4"
        
        cmd = [
            "ffmpeg", "-y",
            "-loop", "1",
            "-i", str(image_path),
            "-t", str(duration),
            "-vf", f"scale={self.width}:{self.height}:force_original_aspect_ratio=increase,crop={self.width}:{self.height}",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            str(output)
        ]
        
        subprocess.run(cmd, capture_output=True, check=True, timeout=60)
        return output
    
    def _compose_fallback(
        self,
        bg_path: Path,
        audio: AudioFile,
        subtitles: Subtitles,
        output_path: Path,
    ) -> Path:
        """Composition de secours avec sous-titres SRT basiques."""
        console.print("[yellow]Utilisation du mode fallback (sous-titres basiques)...[/yellow]")
        
        srt_path = subtitles.srt_path
        srt_escaped = str(srt_path).replace("\\", "/").replace(":", "\\:")
        
        # Style sous-titres basique mais lisible
        subtitle_style = (
            "FontName=Arial Black,"
            "FontSize=60,"
            "PrimaryColour=&H00FFFFFF,"
            "OutlineColour=&H00000000,"
            "Outline=4,"
            "Shadow=2,"
            "MarginV=150"
        )
        
        cmd = [
            "ffmpeg", "-y",
            "-i", str(bg_path),
            "-i", str(audio.path),
            "-vf", f"subtitles='{srt_escaped}':force_style='{subtitle_style}'",
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "20",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg fallback failed: {result.stderr}")
        
        console.print(f"[green]✓ Vidéo générée (fallback) : {output_path}[/green]")
        return output_path


class VideoPipeline:
    """Pipeline complet : audio → sous-titres → vidéo PRO."""
    
    def __init__(self):
        self.subtitle_generator = SubtitleGenerator()
        self.video_composer = VideoComposerPro()
    
    def process(
        self,
        script: Script,
        audio: AudioFile,
        background_image: Optional[Path] = None,
    ) -> Video:
        """
        Traite un script/audio complet jusqu'à la vidéo finale.
        
        Args:
            script: Script source
            audio: Audio généré
            background_image: Image de fond optionnelle (sinon Pexels)
        
        Returns:
            Video avec tous les chemins
        """
        settings.ensure_directories()
        
        # 1. Générer les sous-titres
        subtitles = self.subtitle_generator.generate(audio.path, script.id)
        
        # 2. Composer la vidéo PRO
        video_path = settings.output_dir / "videos" / f"noradar_{script.format.value}_{script.id}.mp4"
        
        self.video_composer.compose(
            script=script,
            audio=audio,
            subtitles=subtitles,
            output_path=video_path,
            background_image=background_image,
        )
        
        # 3. Créer l'objet Video
        video = Video(
            id=script.id,
            script=script,
            audio=audio,
            subtitles=subtitles,
            video_path=video_path,
            status=VideoStatus.VIDEO_READY,
        )
        
        console.print(f"[bold green]✓ Vidéo PRO complète : {video.filename}[/bold green]")
        return video
